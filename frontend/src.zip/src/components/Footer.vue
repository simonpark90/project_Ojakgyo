<template>
    <div>
        발바닥이에요~
    </div>
</template>

<script>
export default {
}
</script>

<style scoped>

</style>