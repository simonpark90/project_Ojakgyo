export const configureWebpack = {
    devServer: {
        headers: { "Access-Control-Allow-Origin": "*" }
    }
};