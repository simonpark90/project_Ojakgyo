<template>
    <div class="Header">
        여기가 배너 될거임
        <Nav />
    </div>
</template>

<script>
import Nav from "@/components/Nav.vue";


export default {
    name: "Header",
    components:{
        Nav
    }
}
</script>

<style scoped>

</style>